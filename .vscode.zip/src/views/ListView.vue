<script setup lang="ts">
import TodoList from '../components/TodoList.vue'
</script>

<template>
  <main><TodoList /></main>
</template>
